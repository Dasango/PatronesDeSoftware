package mainHelpers;

import crud.ServicioProductoImple;
import dbConfig.DbConfig;
import dbConfig.SingletonDbConector;
import model.Producto;

import java.util.ArrayList;
import java.util.List;

public class Init {
    private static SingletonDbConector conector;
    private static ServicioProductoImple crud;

    public static void connectToBase(){

        conector= SingletonDbConector.getInstance(new DbConfig());

    }

    public static void startCrudService(){

        crud = new ServicioProductoImple();

        crud.setDbConfig(conector);

    }

    public static void accessMethodCrud() {
        ProductServiceDisplay display= new ProductServiceDisplay(crud);

        int option;
        do {
            TextMenu.mostrarMenuPrincipal();

            try {

                option = InputHelper.leerInt("Seleccione una opcion: ");
                switch (option) {
                    case 1:
                        display.insertarProducto();
                        break;
                    case 2:
                        display.actualizarProducto();
                        break;
                    case 3:
                        display.eliminarProducto();
                        break;
                    case 4:
                        display.buscarProducto();
                        break;
                    case 5:
                        display.listarProductosBD();
                        break;
                    case 6:
                        System.out.println("Saliendo del sistema...");
                        break;
                    default:
                        System.out.println("Opcion no valida. Por favor ingrese un numero del 1 al 6.");
                }

            } catch (Exception e) {
                System.out.println("Error inesperado: " + e.getMessage());
                option = 0;
            }

        } while (option != 6);
    }


}