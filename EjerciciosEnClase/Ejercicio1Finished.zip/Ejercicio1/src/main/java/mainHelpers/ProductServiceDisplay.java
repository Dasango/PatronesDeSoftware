package mainHelpers;


import Factory.FactoryImple;
import crud.ServicioProductoImple;
import model.Producto;

import java.util.ArrayList;
import java.util.List;


public class ProductServiceDisplay {
    private final ServicioProductoImple crud;

    public ProductServiceDisplay(ServicioProductoImple crud) {
        this.crud = crud;
    }

    public Producto ProductByBuilder() {
        String nombre = InputHelper.leerString("Ingrese nombre del producto: ");
        double precio = InputHelper.leerDouble("Ingrese precio del producto: ");
        int cantidad = InputHelper.leerInt("Ingrese cantidad del producto: ");

        return Producto.builder()
                .nombre(nombre)
                .precio(precio)
                .cantidad(cantidad)
                .build();
    }

    public Producto ProductByFactory() {
        String nombre = InputHelper.leerString("Ingrese nombre del producto: ");
        double precio = InputHelper.leerDouble("Ingrese precio del producto: ");
        int cantidad = InputHelper.leerInt("Ingrese cantidad del producto: ");

        FactoryImple factory = new FactoryImple();
        factory.init("model");

        Producto prod = factory.create("producto");

        if (prod != null) {
            prod.setNombre(nombre);
            prod.setPrecio(precio);
            prod.setCantidad(cantidad);
        } else {
            System.out.println("Error: No se pudo crear el producto desde la factory.");
        }

        return prod;
    }

    public void insertarProducto() {
        TextMenu.mostrarMenuCreacionProducto();
        int creationMethod = InputHelper.leerInt("");

        Producto nuevoProducto = null;
        if (creationMethod == 1) {
            nuevoProducto = ProductByFactory();
        } else if (creationMethod == 2) {
            nuevoProducto = ProductByBuilder();
        } else {
            System.out.println("Opcion no valida");
            return;
        }

        crud.create(nuevoProducto);

        System.out.println("Producto creado exitosamente!");
        System.out.println("Producto aniadido: " + nuevoProducto);
    }

    public void actualizarProducto() {
        int updateId = InputHelper.leerInt("Ingrese ID del producto a actualizar: ");

        Producto productoExistente = crud.read(updateId);
        if (productoExistente == null) {
            System.out.println("No se encontro producto con ID " + updateId);
            return;
        }

        System.out.println("Producto actual:");
        System.out.println(productoExistente);

        System.out.println("\nIngrese los nuevos datos (usando Builder):");
        Producto productoActualizado = ProductByBuilder();
        productoActualizado.setId(updateId);

        crud.update(productoActualizado);

        System.out.println("✔ Producto actualizado exitosamente!");
    }

    public void eliminarProducto() {
        int deleteId = InputHelper.leerInt("Ingrese ID del producto a eliminar: ");

        Producto productoAEliminar = crud.read(deleteId);
        if (productoAEliminar == null) {
            System.out.println("No se encontro producto con ID " + deleteId);
            return;
        }

        System.out.println("Producto a eliminar:");
        System.out.println(productoAEliminar);

        String confirmacion = InputHelper.leerString("Esta seguro? (S/N): ");
        if (confirmacion.equalsIgnoreCase("S")) {
            crud.delete(deleteId);
            System.out.println("Producto eliminado exitosamente!");
        } else {
            System.out.println("Operación cancelada");
        }
    }

    public void buscarProducto() {
        int searchId = InputHelper.leerInt("Ingrese ID del producto a buscar: ");

        Producto productoEncontrado = crud.read(searchId);
        if (productoEncontrado != null) {
            System.out.println("\nInformación del producto:");
            System.out.println(productoEncontrado);
        } else {
            System.out.println("No se encontró producto con ID " + searchId);
        }
    }

    public void listarProductosBD() {
        List<Producto> productosBD = crud.listar();

        if (productosBD.isEmpty()) {
            System.out.println("No hay productos registrados en la base de datos");
        } else {
            System.out.println("Total de productos en BD: " + productosBD.size());
            System.out.println("--------------------------------");
            for (Producto p : productosBD) {
                System.out.println(p);
                System.out.println("--------------------------------");
            }
        }
    }
}
