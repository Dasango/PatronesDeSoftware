package mainHelpers;

public class InputHelper {
    public static int leerInt(String mensaje) {
        System.out.print(mensaje);

        try {
            return Integer.parseInt(System.console().readLine());
        } catch (NumberFormatException e) {
            System.out.println("Error: Debe ingresar un numero valido");
            return leerInt(mensaje);
        }
    }

    public static String leerString(String mensaje) {
        System.out.print(mensaje);
        return System.console().readLine();
    }
    public static double leerDouble(String mensaje) {
        System.out.print(mensaje);
        try {
            return Double.parseDouble(System.console().readLine());
        } catch (NumberFormatException e) {
            System.out.println("Error: Debe ingresar un numero decimal valido");
            return leerDouble(mensaje);
        }
    }

}
