package mainHelpers;

public class TextMenu {
    public static void mostrarMenuPrincipal() {
        System.out.println("\n=== Bienvenido al inventario de productos ===");
        System.out.println("1. Insertar producto");
        System.out.println("2. Actualizar producto");
        System.out.println("3. Eliminar producto");
        System.out.println("4. Buscar producto por ID");
        System.out.println("5. Listar todos los productos");
        System.out.println("6. Salir");
    }

    public static void mostrarMenuCreacionProducto() {
        System.out.println("\n--- INSERTAR PRODUCTO ---");
        System.out.println("Seleccione metodo de creacion:");
        System.out.println("1. Por Factory");
        System.out.println("2. Por Builder");
    }
}
