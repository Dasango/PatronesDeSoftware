package interfaces;

import dbConfig.DbConfig;
import dbConfig.SingletonDbConector;
import model.Producto;

import java.util.List;

public interface ServicioProducto {
    void setDbConfig(SingletonDbConector dbConfig);
    void create(Producto p);
    Producto read(int id);
    List<Producto> listar ();
    void update(Producto p);
    void delete(int id);
}