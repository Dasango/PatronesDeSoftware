package model;

import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
@interfaces.MiComponente(name = "producto")
public class Producto {
    private Integer id;
    private String nombre;
    private Double precio;
    private Integer cantidad;
}