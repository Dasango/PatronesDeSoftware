package Main;


import mainHelpers.Init;

public class Main {
    public static void main(String[] args) {

        System.out.println("start");

        Init.connectToBase();
        Init.startCrudService();
        Init.accessMethodCrud();

        System.out.println("finish");
    }
}
