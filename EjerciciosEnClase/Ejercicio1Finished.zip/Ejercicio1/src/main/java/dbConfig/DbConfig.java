package dbConfig;


import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.sql.Connection;
import java.sql.SQLException;

public class DbConfig {

    private HikariDataSource ds = null;
    private HikariConfig config = new HikariConfig();
    {
        config.setJdbcUrl("jdbc:sqlite:C:/Users/David/Downloads/db.db/");
        config.setUsername("root");
        config.setPassword("");
        config.setConnectionTimeout(3000);
        ds = new HikariDataSource(config);
    }
    public Connection getConnection() {
        try {
            return ds.getConnection();
        }catch(SQLException e) {
            throw new RuntimeException(e);
        }
    }
}