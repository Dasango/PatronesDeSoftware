package dbConfig;

import java.sql.Connection;
import java.sql.SQLException;

public class SingletonDbConector{
    private static SingletonDbConector instancia = null;
    private static DbConfig dbCon = null;

    private SingletonDbConector() {

        try {
            var con = dbCon.getConnection();
        } catch(Exception e) {
            e.printStackTrace();
        }

    }

    public static SingletonDbConector getInstance(DbConfig c) {
        dbCon = c;
        if(instancia == null) {
            instancia = new SingletonDbConector();}
        else{
            System.out.println();
        }
        return instancia;
    }
    public Connection getConnection() {
        return dbCon.getConnection();
    }
}
